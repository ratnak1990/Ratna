package com.task1.main;

interface  Shape {
	
	
	float pi=3.14f;
	
	public float findArea(float var) ;
	

	

}
