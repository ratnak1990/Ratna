package com.task1.main;

public class Circle implements Shape {

	private float radius;
	
	
	
	
	public float getRadius() {
		return radius;
	}



	public void setRadius(float d) {
		this.radius = d;
	}



	@Override
	public float findArea(float rad) {
		
		return pi*radius*radius;
		
		
	}

}
