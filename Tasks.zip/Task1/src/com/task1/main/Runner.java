package com.task1.main;

public class Runner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Circle cir=new Circle();
	cir.setRadius(5.5f);
	float area=cir.findArea(cir.getRadius());
	
	System.out.println("Area =" + area);
	
	
	}

}
