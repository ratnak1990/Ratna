package com.task2.main;

public class TandemBike extends Bike{
	
	String model;

	public TandemBike(int speed, String colour, String type, int gears,String model) {
		super(speed, colour, type, gears);
		this.model=model;
		
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return getSpeed()+" "+getColour()+ " "+ getType()+" "+getGears()+" "+ model;
	}

}
