package com.task2.main;

public class MountainBike extends Bike {

	String model;
	public MountainBike(int speed, String colour, String type, int gears,String model) {
		super(speed, colour, type, gears);
		this.model=model;
	}
	
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return getSpeed()+" "+getColour()+ " "+ getType()+" "+getGears()+" "+ model;
	}

}
