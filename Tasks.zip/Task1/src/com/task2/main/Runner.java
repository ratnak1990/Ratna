package com.task2.main;

public class Runner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MountainBike mb=new MountainBike(5, "white", "mountain bike", 2, "mb-102");
		System.out.println(mb.toString());
		RoadBike rb=new RoadBike(6, "red", "Road Bike", 4, "rb-101");
		System.out.println(rb.toString());
		TandemBike tb=new TandemBike(4, "purple", "Tandem Bike",3, "tb-45");
		System.out.println(tb.toString());
	}

}
