package com.task2.main;

public class Bike {
	
	private int speed;
	private String colour;
	private String type;
	private int gears;
	
	public Bike(int speed,String colour,String type,int gears) {
		
		this.speed=speed;
		this.colour=colour;
		this.type=type;
		this.gears=gears;
		
		
	}
	
	
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	public String getColour() {
		return colour;
	}
	public void setColour(String colour) {
		this.colour = colour;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getGears() {
		return gears;
	}
	public void setGears(int gears) {
		this.gears = gears;
	}
	

}
