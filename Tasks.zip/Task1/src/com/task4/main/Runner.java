package com.task4.main;

public class Runner {

	
	public static void main(String[] args)
	{
		Integer i=10;
		Integer j=10;
		boolean res=i.equals(j);
		//System.out.println(res);
		
		Student s1=new Student();
		Student s2=new Student();
		s1.setId(1);
		s1.setName("Ratna");
		s2.setId(1);
		s2.setName("Ratna");
		boolean res1=s1.equals(s2);
		System.out.println(res1);

	
	}
}
