package com.task3.main;

public class Cylinder  {

	private Circle c;
	private Rectangle r;
	
	public Cylinder(Circle c,Rectangle r) {
		
		this.c=c;
		this.r=r;
	}
	
	public float findArea(Circle c,Rectangle r)
	{
		System.out.println("Area of circle "+c.calculateArea(c.getRadius()));
		System.out.println("Area of Rectangle "+r.calculateArea(r.getLength(), r.getBreadth()));
		return (c.calculateArea(c.getRadius()) + r.calculateArea(r.getLength(), r.getBreadth()));
	}
}
