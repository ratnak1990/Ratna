package com.task3.main;

public class Circle {
	
	final float pi=3.14f;
	int radius;
	public int getRadius() {
		return radius;
	}
	public void setRadius(int radius) {
		this.radius = radius;
	}
	
	public float calculateArea(int radius)
	{
		return pi*radius*radius;
				
		
	}
	
	

}
