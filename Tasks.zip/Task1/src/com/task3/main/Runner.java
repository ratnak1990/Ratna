package com.task3.main;

public class Runner {

	public static void main(String[] args) {
		
		Circle c=new Circle();
		c.setRadius(2);
		Rectangle r=new Rectangle(1, 2);
		Cylinder cd=new Cylinder(c, r);
		float area=cd.findArea(c, r);
		System.out.println("Area = " + area);
		
		
	}

}
